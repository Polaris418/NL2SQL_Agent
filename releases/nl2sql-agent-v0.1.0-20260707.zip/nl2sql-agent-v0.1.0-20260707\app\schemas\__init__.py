"""Shared schemas."""
